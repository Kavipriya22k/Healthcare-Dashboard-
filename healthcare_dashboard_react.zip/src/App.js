import Sidebar from './components/Sidebar';
import Header from './components/Header';
import SummaryCard from './components/SummaryCard';
import PatientChart from './components/LineChart';
import UpcomingAppointments from './components/UpcomingAppointments';
import { summaryData, appointments } from './data/mockData';
import './styles/main.css';

function App() {
  return (
    <div className="dashboard">
      <Sidebar />
      <div className="main-content">
        <Header />
        <div className="summary-section">
          {summaryData.map((card, i) => (
            <SummaryCard key={i} {...card} />
          ))}
        </div>
        <PatientChart />
        <UpcomingAppointments appointments={appointments} />
      </div>
    </div>
  );
}

export default App;