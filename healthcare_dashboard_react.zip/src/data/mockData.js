export const summaryData = [
  { title: "Today's Patients", count: 36, bgColor: "#e0f7fa", icon: "🧍‍♂️" },
  { title: "Appointments", count: 12, bgColor: "#fce4ec", icon: "📅" },
];

export const appointments = [
  { name: "John Doe", time: "10:00 AM", status: "Confirmed", img: "https://via.placeholder.com/40" },
  { name: "Jane Smith", time: "11:30 AM", status: "Pending", img: "https://via.placeholder.com/40" },
];