export default function Sidebar() {
  return (
    <div className="sidebar">
      <div className="logo">FitPeo</div>
      <ul className="nav">
        <li>Dashboard</li>
        <li>Patients</li>
        <li>Appointments</li>
        <li>Settings</li>
      </ul>
    </div>
  );
}