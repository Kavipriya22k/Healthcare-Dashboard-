export default function SummaryCard({ title, count, icon, bgColor }) {
  return (
    <div className="summary-card" style={{ backgroundColor: bgColor }}>
      <div className="icon">{icon}</div>
      <div>
        <p>{title}</p>
        <h3>{count}</h3>
      </div>
    </div>
  );
}