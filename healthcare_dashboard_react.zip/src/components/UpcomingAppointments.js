export default function UpcomingAppointments({ appointments }) {
  return (
    <div className="appointments">
      <h3>Upcoming Appointments</h3>
      {appointments.map((apt, i) => (
        <div key={i} className="appointment-card">
          <img src={apt.img} alt="patient" className="patient-img" />
          <div>
            <p>{apt.name}</p>
            <span>{apt.time}</span>
          </div>
          <span className={`status ${apt.status.toLowerCase()}`}>{apt.status}</span>
        </div>
      ))}
    </div>
  );
}