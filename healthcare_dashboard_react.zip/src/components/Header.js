export default function Header() {
  return (
    <div className="header">
      <h2>Hello, Sarah</h2>
      <div className="header-right">
        <span>May 28, 2025</span>
        <i className="icon-bell">🔔</i>
        <img src="https://via.placeholder.com/30" alt="avatar" className="avatar" />
      </div>
    </div>
  );
}